﻿# Ega Rezky Ghinati-(22305144002)-Bab Kalkulus Subbab Turunan
---

# BAB 3. TURUNAN FUNGSI

MATERI TURUNAN FUNGSI PADA EMT Dibuat Oleh :


NAMA  : EGA REZKY GHINATI


KELAS : MATEMATIKA E


NIM   : 22305144002


Cakupan materi :


-Definisi turunan


-Sifat-sifat turunan


-Turunan fungsi aljabar, trigonometri, eksponensial, logaritma,dan
komposisi fungsi.


-Visualisasi dan kurva fungsi


-Aplikasi turunan


# 1. Definisi Turunan

     Turunan fungsi atau bisa disebut juga differensial merupakan  

konsep yang mengukur perubahan instan dari suatu fungsi terhadap
perubahan variabel independen. Turunan atau differensial suatu fungsi
menggambarkan seberapa cepat nilai fungsi tersebut berubah pada titik
tertentu dalam domain fungsi.


Secara umum, jika "f(x)" adalah suatu fungsi yang tergantung pada
variabel "x," maka turunan atau differensialnya, disimbolkan sebagai
"f'(x)" atau "df/dx," didefinisikan sebagai berikut


Di sini, "h" adalah perubahan kecil dalam variabel "x." Ketika "h"
mendekati nol, kita mendapatkan perubahan instan dari fungsi "f(x)"
pada titik "x".


# 2. Sifat-sifat Turunan

1. Sifat Linear


Turunan dari jumlah atau selisih dua fungsi adalah jumlah atau selisih
dari turunan-turunan fungsi-fungsi tersebut.


2. Aturan Perkalian


Turunan dari perkalian dua fungsi adalah hasil dari turunan pertama
dikalikan dengan fungsi kedua ditambah fungsi pertama dikalikan dengan
turunan kedua.


3. Aturan Rantai(Chain Rule)


Aturan rantai digunakan ketika kita memiliki komposisi fungsi, yaitu
suatu fungsi yang terdiri dari fungsi-fungsi lain. Aturan rantai
mengatakan bahwa turunan dari fungsi komposisi adalah produk dari
turunan-turunan fungsi-fungsi tersebut.


4. Turunan Konstanta


Turunan dari suatu konstanta adalah nol.


5. Turunan Identitas


Turunan dari x terhadap x adalah 1.


6. Turunan dari x^n


Jika


dimana n adalah bilangan bulat positif, maka


7. Turunan Eksponensial


Turunan dari fungsi eksponensial, seperti




adalah dirinya sendiri, yaitu


8. Turunan Logaritma


Turunan dari logaritma alami, seperti




adalah 1/x, yaitu


# 3. TURUNAN FUNGSI ALJABAR

    3.1 Definisi  
       Turunan fungsi aljabar adalah proses untuk menemukan turunan  

(differensial) dari fungsi matematika yang termasuk dalam kategori
aljabar. Fungsi-fungsi aljabar adalah fungsi yang terdiri dari
operasi-operasi aljabar dasar, seperti penambahan, pengurangan,
perkalian, dan pembagian. Contoh umum dari fungsi aljabar yaitu fungsi
linier, fungsi pangkat, fungsi akar, fungsi irasional, dan masih
banyak lainnya.


    3.2 Contoh Soal &amp; Visualisasi Kurvanya  

Menggunakan definisi limit


\>$showev('limit(((x+h)^n-x^n)/h,h,0)) // turunan x^n


$$\lim_{h\rightarrow 0}{\frac{\left(x+h\right)^{n}-x^{n}}{h}}=n\,x^{n
 -1}$$Pembuktian




Untuk




Dengan




maka




Jadi, terbukti benar bahwa


#Visualisasi grafiknya


\>plot2d(["x^2","2\*x^(2-1)"],color=[blue,red]): //grafik fungsi dan turunannya


![images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-002.png](images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-002.png)

#Cara pertama (definisi limit)


\>$showev('limit(((2\*(x+h)^2 + 5\*(x+h) + 9) - (2\*x^2 + 5\*x + 9))/h,h,0))// turunan 


$$\lim_{h\rightarrow 0}{\frac{2\,\left(x+h\right)^2-2\,x^2+5\,\left(x
 +h\right)-5\,x}{h}}=4\,x+5$$Pembuktian


\>p &= expand((2\*(x+h)^2 + 5\*(x+h) + 9) - (2\*x^2 + 5\*x + 9))|simplify; $p //pembilang dijabarkan dan disederhanakan


$$4\,h\,x+2\,h^2+5\,h$$\>q &=ratsimp(p/h); $q // ekspresi yang akan dihitung limitnya disederhanakan (dibagi h)


$$4\,x+2\,h+5$$\>$limit(q,h,0) // nilai limit sebagai turunan


$$4\,x+5$$Pada cara pertama, menggunakan definisi limit yang sudah dituliskan di
atas, kemudian pembilangnya dijabarkan dan disederhanakan lalu dibagi
dengan h. Setelah itu, sesuai dengan definisi limit, ambil batas
(limit) saat "h" mendekati nol sehingga didapatkan turunan atau
derivatif dari fungsi "f(x)" pada titik "x" yaitu 4x+5.


#Cara kedua(menggunakan formula diff)


\>function f(x) &= 2\*x^2+5\*x+9 //Mendefinisikan fungsi f(x)


    
                                   2
                                2 x  + 5 x + 9
    

\>$showev('diff(f(x),x))


$$\frac{d}{d\,x}\,\left(2\,x^2+5\,x+9\right)=4\,x+5$$\>function df(x) &=diff(f(x),x)// df(x)=f'(x)


    
                                   4 x + 5
    

\>plot2d(["f(x)","df(x)"],color=[blue,red]): //grafik fungsi dan turunannya


![images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-008.png](images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-008.png)

#Cara pertama (definisi limit)


\>$showev('limit(((2\*(x+h)-5)/((x+h) + 2) - (2\*x-5)/(x+2))/h,h,0))// turunan 2x^2+5


$$\lim_{h\rightarrow 0}{\frac{\frac{2\,\left(x+h\right)-5}{x+h+2}-
 \frac{2\,x-5}{x+2}}{h}}=\frac{9}{x^2+4\,x+4}$$\>p &= expand((2\*(x+h)-5)/((x+h) + 2) - (2\*x-5)/(x+2))|simplify; $p //pembilang dij


$$\frac{2\,x}{x+h+2}+\frac{2\,h}{x+h+2}-\frac{5}{x+h+2}-\frac{2\,x}{x
 +2}+\frac{5}{x+2}$$\>q &=ratsimp(p/h); $q // ekspresi yang akan dihitung limitnya disederhanakan


$$\frac{9}{x^2+\left(h+4\right)\,x+2\,h+4}$$\>$limit(q,h,0) // nilai limit sebagai turunan


$$\frac{9}{x^2+4\,x+4}$$#Cara kedua (menggunakan formula diff)


\>function f(x) &= (2\*x-5)/(x+2)


    
                                   2 x - 5
                                   -------
                                    x + 2
    

\>$showev('diff(f(x),x))


$$\frac{d}{d\,x}\,\left(\frac{2\,x-5}{x+2}\right)=\frac{2}{x+2}-
 \frac{2\,x-5}{\left(x+2\right)^2}$$#Visualisasi grafiknya


\>plot2d(["f(x)","df(x)"],color=[blue,red]): //grafik fungsi dan turunannya


![images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-014.png](images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-014.png)

# 4. Turunan Fungsi Trigonometri

    4.1 Definisi  
        Turunan fungsi trigonometri adalah proses untuk menghitung  

turunan (differensial) dari fungsi trigonometri, seperti sin(x),
cos(x), tan(x), dan fungsi trigonometri lainnya.


    4.2 Contoh Soal dan Visualisai Grafiknya  

\>function f(x) &= sin(x) // mendifinisikan fungsi f


    
                                    sin(x)
    

\>function df(x) &=diff(f(x),x) // df(x) = f'(x)


    
                                    cos(x)
    

Pembuktian


Jadi, terbukti benar bahwa


\>plot2d(["f(x)","df(x)"],color=[blue,red]): //grafik fungsi dan turunannya


![images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-015.png](images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-015.png)

\>function f(x) &= arcsin(x) // mendifinisikan fungsi f


    
                                  arcsin(x)
    

\>$showev('limit((asin(x+h)-asin(x))/h,h,0)) // turunan arcsin(x)


$$\lim_{h\rightarrow 0}{\frac{\arcsin \left(x+h\right)-\arcsin x}{h}}=
 \frac{1}{\sqrt{1-x^2}}$$\>plot2d(["log(x)","1/(sqrt(1-x^2))"],color=[blue,red]): //grafik fungsi dan turunannya


![images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-017.png](images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-017.png)

\>function f(x) &= sin(3\*x^5+7)^2


    
                                   2    5
                                sin (3 x  + 7)
    

\>$showev('diff(f(x),x))


$$\frac{d}{d\,x}\,\sin ^2\left(3\,x^5+7\right)=30\,x^4\,\cos \left(3
 \,x^5+7\right)\,\sin \left(3\,x^5+7\right)$$Mencari turunan menggunakan formula diff. Diff sendiri merupakan
formula pada Euler Math Toolbox yang berfungsi untuk mencari turunan. 


\>$% with x=3


$${\it \%at}\left(\frac{d}{d\,x}\,\sin ^2\left(3\,x^5+7\right) , x=3
 \right)=2430\,\cos 736\,\sin 736$$Saat x=3 diperoleh turunan pertama seperti dituliskan di atas


\>$float(%)


$${\it \%at}\left(\frac{d^{1.0}}{d\,x^{1.0}}\,\sin ^2\left(3.0\,x^5+
 7.0\right) , x=3.0\right)=1198.728637211748$$Jika turunan pertama saat x=3 dioperasikan menghasilkan seperti yang
dituliskan di atas.


\>plot2d(f,0,3.1):


![images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-021.png](images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-021.png)

'0': Ini adalah batas bawah dari rentang sumbu-x yang akan digambarkan
dalam grafik. Dalam hal ini, garis awal grafik dimulai dari x=0.


'3.1': Ini adalah batas atas dari rentang sumbu-x yang akan
digambarkan dalam grafik. Dalam hal ini, garis akhir grafik adalah
x=3.1.


Hasil dari perintah plot2d(f,0,3.1) adalah grafik dari fungsi f(x)
yang digambarkan dari rentang x dari 0 hingga 3.1. Jadi, grafik ini
akan menunjukkan bagaimana fungsi f(x) berubah saat x bergerak dari 0
hingga 3.1.


# 5. Turunan Fungsi Eksponensial

5.1 Definisi


         Turunan dari fungsi eksponensial ditemukan berdasarkan aturan
dasar turunan. Fungsi eksponensial dasar adalah fungsi dalam bentuk
"a^x," di mana "a" adalah konstanta positif dan "x" adalah variabel
independen.


5.2 Contoh Soal dan Visualisasi Grafik


\>function f(x) &= 3\*x^x


    
                                        x
                                     3 x
    

\>&assume(x\>0); $showev('limit((f(x+h)-f(x))/h,h,0)) // turunan f(x)=3x^x


$$\lim_{h\rightarrow 0}{\frac{3\,\left(x+h\right)^{x+h}-3\,x^{x}}{h}}=
 x^{x}\,\left(3\,\log x+3\right)$$\>plot2d(["f(x)","x^x\*(3\*log(x) +3)"],color=[blue,red]): //grafik fungsi dan turunannya


![images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-023.png](images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-023.png)

\>$factor(E^(x+h)-E^x)


$$\left(e^{h}-1\right)\,e^{x}$$Jika langsung menggunakan definisi limit maka akan error sehingga
e^(x+h) - e^x perlu difaktorkan dahulu.


\>$showev('limit(factor((E^(x+h)-E^x)/h),h,0)) // turunan f(x)=e^x


$$\left(\lim_{h\rightarrow 0}{\frac{e^{h}-1}{h}}\right)\,e^{x}=e^{x}$$Setelah difaktorkan maka bisa dicari limitnya dan diperoleh turunan
pertama dari e^x adalah fungsi itu sendiri (ingat kembali sifat
turunan eksponensial).


\>plot2d(["E^x","E^x"],color=[blue,red]): //grafik fungsi dan turunannya


![images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-026.png](images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-026.png)

# 6. Turunan Fungsi Logaritma

     6.1 Definisi  
         Turunan dari fungsi logaritma adalah aturan turunan yang  

digunakan untuk menghitung turunan fungsi logaritma alami (logaritma
berbasis e, biasanya disimbolkan sebagai "ln(x)") dan logaritma
berbasis lain (seperti logaritma berbasis 10 atau berbasis lainnya).


     6.2 Contoh Soal dan Visualisasi Grafiknya  

\>$showev('limit((log(x+h)-log(x))/h,h,0)) // turunan log(x)


$$\lim_{h\rightarrow 0}{\frac{\log \left(x+h\right)-\log x}{h}}=
 \frac{1}{x}$$Pembuktian




Jadi, terbukti benar bahwa


\>plot2d(["log(x)","1/x"],color=[blue,red]): //grafik fungsi dan turunannya


![images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-028.png](images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-028.png)

# 7. Turunan Fungsi Komposisi

      7.1 Definisi          Turunan fungsi komposisi adalah aturan  

turunan yang digunakan untuk menghitung turunan dari fungsi yang
merupakan hasil dari komposisi dua atau lebih fungsi.


     7.2 Contoh Soal dan Visualisasi Grafiknya  

\>function f(x) &= x^2+1


    
                                     2
                                    x  + 1
    

\>function g(x) &= x+5


    
                                    x + 5
    

\>$showev('diff(f(g(x)),x))


$$\frac{d}{d\,x}\,\left(\left(x+5\right)^2+1\right)=2\,\left(x+5
 \right)$$\>plot2d(["f(x)","g(x)","2\*(x+5)"],color=[blue,red,green]): //grafik fungsi dan turunannya


![images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-030.png](images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-030.png)

# 9. Aplikasi Turunan

     Aplikasi dari turunan yaitu untuk mengoptimasi fungsi. Turunan  

digunakan dalam optimisasi matematika untuk menemukan titik maksimum
atau minimum dari suatu fungsi (nilai ekstrim).


\>function f(x) &=5\*cos(2\*x)-2\*x\*sin(2\*x) // mendifinisikan fungsi f


    
                          5 cos(2 x) - 2 x sin(2 x)
    

Langkah pertama yaitu mendefinisikan fungsinya dahulu supaya
memudahkan dalam mencari turunan dan visualisasi grafiknya.


\>function df(x) &=diff(f(x),x) // df(x) = f'(x)


    
                         - 12 sin(2 x) - 4 x cos(2 x)
    

Langkah kedua, mencari turunannya.


\>xp=solve("df(x)",1,2,0) // solusi f'(x)=0 pada interval [1, 2]


    1.35822987384

Mencari nilai ekstrimnya, nilai ekstrim diperoleh saat turunan
pertamanya = 0.


\>df(xp), f(xp) // cek bahwa f'(xp)=0 dan nilai ekstrim di titik tersebut


    0
    -5.67530133759

Diperoleh titik ekstrim


\>plot2d(["f(x)","df(x)"],0,2\*pi,color=[blue,red]): //grafik fungsi dan turunannya


![images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-031.png](images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-031.png)

# Latihan Soal

1. Tentukan nilai turunan berikut dan sketsakan grafiknya.


\>function f(x) &= 3\*x^2+4; $f(x)


$$3\,x^2+4$$\>function df(x) &= limit((f(x+h)-f(x))/h,h,0); &df(x)//df(x)=f'(x)


    
                                     6 x
    

\>plot2d(["f(x)","df(x)"],color=[blue,red]):


![images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-033.png](images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-033.png)

2. Carilah turunan dari fungsi berikut


\>function f(x) &= (2\*x-1)/(x-4); $f(x)


$$\frac{2\,x-1}{x-4}$$\>function df(x) &= limit((f(x+h)-f(x))/h,h,0); $df(x) // df(x) = f'(x)


$$-\frac{7}{x^2-8\,x+16}$$\>plot2d(["f(x)","df(x)"],color=[blue,red]):


![images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-036.png](images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-036.png)

3. Carilah turunan fungsi berikut.


\>function f(x) &= (2\*sin(x)+3\*cos(x)); $f(x)


$$2\,\sin x+3\,\cos x$$\>function df(x) &= limit((f(x+h)-f(x))/h,h,0); &df(x)


    
                             2 cos(x) - 3 sin(x)
    

\>plot2d(["f(x)","df(x)"],color=[blue,red]):


![images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-038.png](images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-038.png)

4. Tentukan turunan dan grafik fungsi berikut.


\>function f(x) &= (sin(x)+cos(x))/(cos(x)); $f(x)


$$\frac{\sin x+\cos x}{\cos x}$$\>function df(x) &= limit((f(x+h)-f(x))/h,h,0); $df(x) // df(x) = f'(x)


$$\frac{\sin ^2x+\cos ^2x}{\cos ^2x}$$\>plot2d(["f(x)","df(x)"],color=[blue,red]):


![images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-041.png](images/Ega%20Rezky%20Ghinati-(22305144002)-Bab%20Kalkulus%20Subbab%20Turunan-041.png)

---

# Terima Kasih

